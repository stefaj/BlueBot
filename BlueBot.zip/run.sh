#!/bin/bash

mono BasicBot/bin/Debug/BasicBot.exe $1
